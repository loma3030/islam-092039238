enum StatusRequest {
  loading,
  success,
  failure,
  offlinefailure,
  serverfailure,
  serverException
}
