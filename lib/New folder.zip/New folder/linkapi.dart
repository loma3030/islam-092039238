class AppLink {
  static const String server = "http://localhost/Zahra_store/zahra";
  static const String test = "$server/test.php";

  static const String signUp =
      "http://localhost/Zahra_store/zahra/auth/signup.php";
}
