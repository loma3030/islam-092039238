import 'package:e_commerce_app/core/constant/routes.dart';
import 'package:e_commerce_app/core/midelware/mymidelware.dart';
//import 'package:e_commerce_app/test_view.dart';
import 'package:e_commerce_app/view/screen/Onbording.dart';
import 'package:e_commerce_app/view/screen/auth/forgetpassword/forgetpassword.dart';
import 'package:e_commerce_app/view/screen/auth/forgetpassword/resetpassword.dart';
import 'package:e_commerce_app/view/screen/auth/forgetpassword/success_resetpassword.dart';
import 'package:e_commerce_app/view/screen/auth/forgetpassword/verfiyCode.dart';
import 'package:e_commerce_app/view/screen/auth/login.dart';
import 'package:e_commerce_app/view/screen/auth/signup.dart';
import 'package:e_commerce_app/view/screen/auth/success_signup.dart';
import 'package:e_commerce_app/view/screen/auth/verfiycodesignup.dart';
import 'package:e_commerce_app/view/screen/language.dart';
import 'package:get/get.dart';

List<GetPage<dynamic>>? routes = [
  GetPage(
      name: "/", page: () => const Language(), middlewares: [MyMiddleWare()]),
  //GetPage(name: "/", page: () => TestView()),
  GetPage(name: AppRoutes.login, page: () => const Login()),
  GetPage(name: AppRoutes.signUp, page: () => const signUp()),
  GetPage(name: AppRoutes.forgetPassword, page: () => const Forgetpassword()),
  GetPage(name: AppRoutes.verfiyCode, page: () => const Verfiycode()),
  GetPage(name: AppRoutes.resetPassword, page: () => const resetpassword()),
  GetPage(
      name: AppRoutes.successResetpassword,
      page: () => const SuccessResetPassword()),
  GetPage(name: AppRoutes.successSignUp, page: () => const SuccessSignUp()),
  GetPage(name: AppRoutes.OnBording, page: () => const OnBording()),
  GetPage(
      name: AppRoutes.verfiyCodeSignUp, page: () => const Verfiycodesignup()),
];
